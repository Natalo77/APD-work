/**
 * Various semaphore implementations.  All should implement the SemaphoreInterface.
 */
package semaphore;