package searcher;

/**
 * Created by u1661665 on 08/10/2018.
 */
public class CleverSearcher extends Searcher
{


    CleverSearcher(int[] array, int k)
    {
        super(array, k);
    }

    @Override
    public int findElement() throws IndexingError
    {
        int k = super.getIndex();
        int[] array = super.getArray();

        int[] auxArray = new int[k];
        for(int x = 0; x<k; x++)
        {
            auxArray[x] = array[x];
        }

        //sort auxarray

        for(int x = k; x < array.length; x++)
        {
            if(array)
        }
        return 0;
    }
}
