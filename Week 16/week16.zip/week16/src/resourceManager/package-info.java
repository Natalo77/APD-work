/**
 * Implements and uses resource managers.
 */
package resourceManager;